<?php
// define('DB_HOST', '127.0.0.1');
// define('DB_USER', 'crmcust8');
// define('DB_PASS', 'AjvA8bbEa9^&kmu2');
// define('DB_NAME', 'crmcust8');

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'jrj_travel');

$time_zone = "Europe/London";

//reset password url encryption - $site->my_encrypt()
$encryption_key = '';

//mail settings
$enable_email = true;

// $customers_statuses = ['Suspect' => 'Suspect','Prospect' => 'Prospect','Active' => 'Active','Inactive' => 'Inactive','Work in progress' => 'Work in progress','Archived' => 'Archived'];
$customers_statuses = ['Active' => 'Active','Inactive' => 'Inactive'];
$recruiters_statuses = ['Suspect' => 'Suspect','Prospect' => 'Prospect','Active' => 'Active','Inactive' => 'Inactive','Work in progress' => 'Work in progress','Archived' => 'Archived'];
$employees_statuses = ['Suspect' => 'Suspect','Prospect' => 'Prospect','Active' => 'Active','Inactive' => 'Inactive','Work in progress' => 'Work in progress','Archived' => 'Archived'];
$suppliers_statuses = ['Suspect' => 'Suspect','Prospect' => 'Prospect','Active' => 'Active','Inactive' => 'Inactive','Work in progress' => 'Work in progress','Archived' => 'Archived'];


$currency_symbol = "£ ";

define('AMADEUS_BASE_URL', 'https://test.api.amadeus.com');
define('AMADEUS_CLIENT_ID', '0Y4ZQaVGFGxLAuTzzoG8tsAAunXDNNUa');
define('AMADEUS_CLIENT_SECRET', 'jQ6L39f3ZOJk1dWD');

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) { http_response_code(500); die('DB connection failed: ' . $mysqli->connect_error); }
$mysqli->set_charset('utf8mb4');
